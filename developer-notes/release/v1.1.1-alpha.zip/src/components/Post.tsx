import { useEffect } from 'react';
import Head from 'next/head';
import { Box, Typography } from '@mui/material';

import PageLayout from '../layouts/PageLayout';
import MarkdownRender from './MarkdownRender';

interface PostProps {
  title: string;
  content: string;
}

const Post: React.FC<PostProps> = ({ title, content }) => {
  useEffect(() => {
    document.title = `${title} | ALIF Blog`;
  }, [title]);

  return (
    <PageLayout>
      <Head>
        <title>{`${title} | ALIF Blog`}</title>
      </Head>
      <Box sx={{ mt: 4, mx: 'auto', maxWidth: '800px' }}>
        <MarkdownRender content={content} />
      </Box>
    </PageLayout>
  );
};

export default Post;
