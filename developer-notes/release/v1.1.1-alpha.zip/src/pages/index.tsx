import PageLayout from '../layouts/PageLayout';
import MainContent from '../components/MainContent';
import homepage_data from '../dist/homepage.json';

const Home: React.FC = () => {
  return (
    <PageLayout>
      <MainContent data={homepage_data} />
    </PageLayout>
  );
};

export default Home;
