"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "lib_markdown_ts";
exports.ids = ["lib_markdown_ts"];
exports.modules = {

/***/ "./lib/markdown.ts":
/*!*************************!*\
  !*** ./lib/markdown.ts ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   getMarkdownFiles: () => (/* binding */ getMarkdownFiles)\n/* harmony export */ });\n/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! fs */ \"fs\");\n/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! path */ \"path\");\n/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst getMarkdownFiles = (directory)=>{\n    const dirents = fs__WEBPACK_IMPORTED_MODULE_0___default().readdirSync(directory, {\n        withFileTypes: true\n    });\n    const files = dirents.flatMap((dirent)=>{\n        const res = path__WEBPACK_IMPORTED_MODULE_1___default().resolve(directory, dirent.name);\n        return dirent.isDirectory() ? getMarkdownFiles(res) : res;\n    });\n    return files.map((file)=>path__WEBPACK_IMPORTED_MODULE_1___default().relative(process.cwd(), file));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9saWIvbWFya2Rvd24udHMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBb0I7QUFDSTtBQUVqQixNQUFNRSxtQkFBbUIsQ0FBQ0M7SUFDL0IsTUFBTUMsVUFBVUoscURBQWMsQ0FBQ0csV0FBVztRQUFFRyxlQUFlO0lBQUs7SUFDaEUsTUFBTUMsUUFBUUgsUUFBUUksT0FBTyxDQUFDLENBQUNDO1FBQzdCLE1BQU1DLE1BQU1ULG1EQUFZLENBQUNFLFdBQVdNLE9BQU9HLElBQUk7UUFDL0MsT0FBT0gsT0FBT0ksV0FBVyxLQUFLWCxpQkFBaUJRLE9BQU9BO0lBQ3hEO0lBQ0EsT0FBT0gsTUFBTU8sR0FBRyxDQUFDLENBQUNDLE9BQVNkLG9EQUFhLENBQUNnQixRQUFRQyxHQUFHLElBQUlIO0FBQzFELEVBQUUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hbGlmLWJsb2cvLi9saWIvbWFya2Rvd24udHM/OTNjOCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZnMgZnJvbSAnZnMnO1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCc7XG5cbmV4cG9ydCBjb25zdCBnZXRNYXJrZG93bkZpbGVzID0gKGRpcmVjdG9yeTogc3RyaW5nKTogc3RyaW5nW10gPT4ge1xuICBjb25zdCBkaXJlbnRzID0gZnMucmVhZGRpclN5bmMoZGlyZWN0b3J5LCB7IHdpdGhGaWxlVHlwZXM6IHRydWUgfSk7XG4gIGNvbnN0IGZpbGVzID0gZGlyZW50cy5mbGF0TWFwKChkaXJlbnQpID0+IHtcbiAgICBjb25zdCByZXMgPSBwYXRoLnJlc29sdmUoZGlyZWN0b3J5LCBkaXJlbnQubmFtZSk7XG4gICAgcmV0dXJuIGRpcmVudC5pc0RpcmVjdG9yeSgpID8gZ2V0TWFya2Rvd25GaWxlcyhyZXMpIDogcmVzO1xuICB9KTtcbiAgcmV0dXJuIGZpbGVzLm1hcCgoZmlsZSkgPT4gcGF0aC5yZWxhdGl2ZShwcm9jZXNzLmN3ZCgpLCBmaWxlKSk7XG59O1xuIl0sIm5hbWVzIjpbImZzIiwicGF0aCIsImdldE1hcmtkb3duRmlsZXMiLCJkaXJlY3RvcnkiLCJkaXJlbnRzIiwicmVhZGRpclN5bmMiLCJ3aXRoRmlsZVR5cGVzIiwiZmlsZXMiLCJmbGF0TWFwIiwiZGlyZW50IiwicmVzIiwicmVzb2x2ZSIsIm5hbWUiLCJpc0RpcmVjdG9yeSIsIm1hcCIsImZpbGUiLCJyZWxhdGl2ZSIsInByb2Nlc3MiLCJjd2QiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./lib/markdown.ts\n");

/***/ })

};
;