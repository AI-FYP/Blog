---
title: "Sadia Jahangir"
---

# Sadia Jahangir

Sadia Jahangir is an experienced software engineer specializing in cutting-edge technologies.
