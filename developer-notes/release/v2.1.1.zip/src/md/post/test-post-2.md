---
title: "Test Post Two"
date: "2024-09-09"
authors:
  - name: "Abdullah Ahmad"
    avatar: "/assets/images/avatar/john-doe.jpg"
tags: ["Introduction", "Welcome"]
description: "Welcome to the new blog! We are excited to share updates and stories with you."
---

# Test Post
This is a test post
