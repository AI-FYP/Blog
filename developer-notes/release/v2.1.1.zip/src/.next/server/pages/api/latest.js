"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/latest";
exports.ids = ["pages/api/latest"];
exports.modules = {

/***/ "gray-matter":
/*!******************************!*\
  !*** external "gray-matter" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("gray-matter");

/***/ }),

/***/ "next/dist/compiled/next-server/pages-api.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages-api.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages-api.runtime.dev.js");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ "(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Flatest&preferredRegion=&absolutePagePath=.%2Fpages%2Fapi%2Flatest.ts&middlewareConfigBase64=e30%3D!":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Flatest&preferredRegion=&absolutePagePath=.%2Fpages%2Fapi%2Flatest.ts&middlewareConfigBase64=e30%3D! ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   routeModule: () => (/* binding */ routeModule)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/pages-api/module.compiled */ \"(api)/./node_modules/next/dist/server/future/route-modules/pages-api/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(api)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"(api)/./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var _pages_api_latest_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/api/latest.ts */ \"(api)/./pages/api/latest.ts\");\n\n\n\n// Import the userland code.\n\n// Re-export the handler (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_latest_ts__WEBPACK_IMPORTED_MODULE_3__, \"default\"));\n// Re-export config.\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_latest_ts__WEBPACK_IMPORTED_MODULE_3__, \"config\");\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesAPIRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES_API,\n        page: \"/api/latest\",\n        pathname: \"/api/latest\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\"\n    },\n    userland: _pages_api_latest_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n\n//# sourceMappingURL=pages-api.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTX0FQSSZwYWdlPSUyRmFwaSUyRmxhdGVzdCZwcmVmZXJyZWRSZWdpb249JmFic29sdXRlUGFnZVBhdGg9LiUyRnBhZ2VzJTJGYXBpJTJGbGF0ZXN0LnRzJm1pZGRsZXdhcmVDb25maWdCYXNlNjQ9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFzRztBQUN2QztBQUNMO0FBQzFEO0FBQ2tEO0FBQ2xEO0FBQ0EsaUVBQWUsd0VBQUssQ0FBQyxpREFBUSxZQUFZLEVBQUM7QUFDMUM7QUFDTyxlQUFlLHdFQUFLLENBQUMsaURBQVE7QUFDcEM7QUFDTyx3QkFBd0IsZ0hBQW1CO0FBQ2xEO0FBQ0EsY0FBYyx5RUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLFlBQVk7QUFDWixDQUFDOztBQUVEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYWxpZi1ibG9nLz85ZTVkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBhZ2VzQVBJUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUtbW9kdWxlcy9wYWdlcy1hcGkvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUta2luZFwiO1xuaW1wb3J0IHsgaG9pc3QgfSBmcm9tIFwibmV4dC9kaXN0L2J1aWxkL3RlbXBsYXRlcy9oZWxwZXJzXCI7XG4vLyBJbXBvcnQgdGhlIHVzZXJsYW5kIGNvZGUuXG5pbXBvcnQgKiBhcyB1c2VybGFuZCBmcm9tIFwiLi9wYWdlcy9hcGkvbGF0ZXN0LnRzXCI7XG4vLyBSZS1leHBvcnQgdGhlIGhhbmRsZXIgKHNob3VsZCBiZSB0aGUgZGVmYXVsdCBleHBvcnQpLlxuZXhwb3J0IGRlZmF1bHQgaG9pc3QodXNlcmxhbmQsIFwiZGVmYXVsdFwiKTtcbi8vIFJlLWV4cG9ydCBjb25maWcuXG5leHBvcnQgY29uc3QgY29uZmlnID0gaG9pc3QodXNlcmxhbmQsIFwiY29uZmlnXCIpO1xuLy8gQ3JlYXRlIGFuZCBleHBvcnQgdGhlIHJvdXRlIG1vZHVsZSB0aGF0IHdpbGwgYmUgY29uc3VtZWQuXG5leHBvcnQgY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgUGFnZXNBUElSb3V0ZU1vZHVsZSh7XG4gICAgZGVmaW5pdGlvbjoge1xuICAgICAgICBraW5kOiBSb3V0ZUtpbmQuUEFHRVNfQVBJLFxuICAgICAgICBwYWdlOiBcIi9hcGkvbGF0ZXN0XCIsXG4gICAgICAgIHBhdGhuYW1lOiBcIi9hcGkvbGF0ZXN0XCIsXG4gICAgICAgIC8vIFRoZSBmb2xsb3dpbmcgYXJlbid0IHVzZWQgaW4gcHJvZHVjdGlvbi5cbiAgICAgICAgYnVuZGxlUGF0aDogXCJcIixcbiAgICAgICAgZmlsZW5hbWU6IFwiXCJcbiAgICB9LFxuICAgIHVzZXJsYW5kXG59KTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cGFnZXMtYXBpLmpzLm1hcCJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Flatest&preferredRegion=&absolutePagePath=.%2Fpages%2Fapi%2Flatest.ts&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "(api)/./pages/api/latest.ts":
/*!*****************************!*\
  !*** ./pages/api/latest.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! fs */ \"fs\");\n/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! path */ \"path\");\n/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var gray_matter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! gray-matter */ \"gray-matter\");\n/* harmony import */ var gray_matter__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(gray_matter__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst POSTS_PER_PAGE = 2;\nfunction handler(req, res) {\n    const postsDirectory = path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), \"md/post\");\n    const fileNames = fs__WEBPACK_IMPORTED_MODULE_0___default().readdirSync(postsDirectory);\n    // Read and parse all markdown files\n    const posts = fileNames.map((fileName)=>{\n        const filePath = path__WEBPACK_IMPORTED_MODULE_1___default().join(postsDirectory, fileName);\n        const fileContents = fs__WEBPACK_IMPORTED_MODULE_0___default().readFileSync(filePath, \"utf8\");\n        const { data } = gray_matter__WEBPACK_IMPORTED_MODULE_2___default()(fileContents);\n        const slug = fileName.replace(/\\.md$/, \"\");\n        return {\n            ...data,\n            slug: fileName.replace(/\\.md$/, \"\"),\n            url: `/${slug}`\n        };\n    });\n    // Sort posts by date (descending)\n    let sortedPosts = posts.sort((a, b)=>new Date(b.date).getTime() - new Date(a.date).getTime());\n    // Req Params\n    const { page = 1, searchQuery = \"\" } = req.query;\n    // Filter\n    if (searchQuery) {\n        const queryLower = searchQuery.toString().toLowerCase();\n        sortedPosts = sortedPosts.filter((post)=>post.title.toLowerCase().includes(queryLower) || post.description && post.description.toLowerCase().includes(queryLower) || post.tag && post.tag.toLowerCase().includes(queryLower));\n    }\n    // Pagination\n    const paginatedPosts = sortedPosts.slice((+page - 1) * POSTS_PER_PAGE, +page * POSTS_PER_PAGE);\n    res.status(200).json({\n        posts: paginatedPosts,\n        totalPosts: sortedPosts.length,\n        totalPages: Math.ceil(sortedPosts.length / POSTS_PER_PAGE)\n    });\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvbGF0ZXN0LnRzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBb0I7QUFDSTtBQUNTO0FBR2pDLE1BQU1HLGlCQUFpQjtBQUVSLFNBQVNDLFFBQVFDLEdBQW1CLEVBQUVDLEdBQW9CO0lBQ3ZFLE1BQU1DLGlCQUFpQk4sZ0RBQVMsQ0FBQ1EsUUFBUUMsR0FBRyxJQUFJO0lBQ2hELE1BQU1DLFlBQVlYLHFEQUFjLENBQUNPO0lBRWpDLG9DQUFvQztJQUNwQyxNQUFNTSxRQUFRRixVQUFVRyxHQUFHLENBQUMsQ0FBQ0M7UUFDM0IsTUFBTUMsV0FBV2YsZ0RBQVMsQ0FBQ00sZ0JBQWdCUTtRQUMzQyxNQUFNRSxlQUFlakIsc0RBQWUsQ0FBQ2dCLFVBQVU7UUFDL0MsTUFBTSxFQUFFRyxJQUFJLEVBQUUsR0FBR2pCLGtEQUFNQSxDQUFDZTtRQUV4QixNQUFNRyxPQUFPTCxTQUFTTSxPQUFPLENBQUMsU0FBUztRQUV2QyxPQUFPO1lBQ0wsR0FBR0YsSUFBSTtZQUNQQyxNQUFNTCxTQUFTTSxPQUFPLENBQUMsU0FBUztZQUNoQ0MsS0FBSyxDQUFDLENBQUMsRUFBRUYsS0FBSyxDQUFDO1FBQ2pCO0lBQ0Y7SUFFQSxrQ0FBa0M7SUFDbEMsSUFBSUcsY0FBY1YsTUFBTVcsSUFBSSxDQUFDLENBQUNDLEdBQUdDLElBQU0sSUFBSUMsS0FBS0QsRUFBRUUsSUFBSSxFQUFFQyxPQUFPLEtBQUssSUFBSUYsS0FBS0YsRUFBRUcsSUFBSSxFQUFFQyxPQUFPO0lBRTVGLGFBQWE7SUFDYixNQUFNLEVBQUVDLE9BQU8sQ0FBQyxFQUFFQyxjQUFjLEVBQUUsRUFBRSxHQUFHMUIsSUFBSTJCLEtBQUs7SUFFaEQsU0FBUztJQUNULElBQUlELGFBQWE7UUFDZixNQUFNRSxhQUFhRixZQUFZRyxRQUFRLEdBQUdDLFdBQVc7UUFDckRaLGNBQWNBLFlBQVlhLE1BQU0sQ0FDOUIsQ0FBQ0MsT0FDQ0EsS0FBS0MsS0FBSyxDQUFDSCxXQUFXLEdBQUdJLFFBQVEsQ0FBQ04sZUFDakNJLEtBQUtHLFdBQVcsSUFBSUgsS0FBS0csV0FBVyxDQUFDTCxXQUFXLEdBQUdJLFFBQVEsQ0FBQ04sZUFDNURJLEtBQUtJLEdBQUcsSUFBSUosS0FBS0ksR0FBRyxDQUFDTixXQUFXLEdBQUdJLFFBQVEsQ0FBQ047SUFFbkQ7SUFFQSxhQUFhO0lBQ2IsTUFBTVMsaUJBQWlCbkIsWUFBWW9CLEtBQUssQ0FBQyxDQUFDLENBQUNiLE9BQU8sS0FBSzNCLGdCQUFnQixDQUFDMkIsT0FBTzNCO0lBRS9FRyxJQUFJc0MsTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztRQUNuQmhDLE9BQU82QjtRQUNQSSxZQUFZdkIsWUFBWXdCLE1BQU07UUFDOUJDLFlBQVlDLEtBQUtDLElBQUksQ0FBQzNCLFlBQVl3QixNQUFNLEdBQUc1QztJQUM3QztBQUNGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYWxpZi1ibG9nLy4vcGFnZXMvYXBpL2xhdGVzdC50cz9lMWRiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBmcyBmcm9tICdmcyc7XG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJztcbmltcG9ydCBtYXR0ZXIgZnJvbSAnZ3JheS1tYXR0ZXInO1xuaW1wb3J0IHR5cGUgeyBOZXh0QXBpUmVxdWVzdCwgTmV4dEFwaVJlc3BvbnNlIH0gZnJvbSAnbmV4dCc7XG5cbmNvbnN0IFBPU1RTX1BFUl9QQUdFID0gMjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaGFuZGxlcihyZXE6IE5leHRBcGlSZXF1ZXN0LCByZXM6IE5leHRBcGlSZXNwb25zZSkge1xuICBjb25zdCBwb3N0c0RpcmVjdG9yeSA9IHBhdGguam9pbihwcm9jZXNzLmN3ZCgpLCAnbWQvcG9zdCcpO1xuICBjb25zdCBmaWxlTmFtZXMgPSBmcy5yZWFkZGlyU3luYyhwb3N0c0RpcmVjdG9yeSk7XG4gIFxuICAvLyBSZWFkIGFuZCBwYXJzZSBhbGwgbWFya2Rvd24gZmlsZXNcbiAgY29uc3QgcG9zdHMgPSBmaWxlTmFtZXMubWFwKChmaWxlTmFtZSkgPT4ge1xuICAgIGNvbnN0IGZpbGVQYXRoID0gcGF0aC5qb2luKHBvc3RzRGlyZWN0b3J5LCBmaWxlTmFtZSk7XG4gICAgY29uc3QgZmlsZUNvbnRlbnRzID0gZnMucmVhZEZpbGVTeW5jKGZpbGVQYXRoLCAndXRmOCcpO1xuICAgIGNvbnN0IHsgZGF0YSB9ID0gbWF0dGVyKGZpbGVDb250ZW50cyk7XG5cbiAgICBjb25zdCBzbHVnID0gZmlsZU5hbWUucmVwbGFjZSgvXFwubWQkLywgJycpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLmRhdGEsXG4gICAgICBzbHVnOiBmaWxlTmFtZS5yZXBsYWNlKC9cXC5tZCQvLCAnJyksXG4gICAgICB1cmw6IGAvJHtzbHVnfWAsXG4gICAgfTtcbiAgfSk7XG5cbiAgLy8gU29ydCBwb3N0cyBieSBkYXRlIChkZXNjZW5kaW5nKVxuICBsZXQgc29ydGVkUG9zdHMgPSBwb3N0cy5zb3J0KChhLCBiKSA9PiBuZXcgRGF0ZShiLmRhdGUpLmdldFRpbWUoKSAtIG5ldyBEYXRlKGEuZGF0ZSkuZ2V0VGltZSgpKTtcblxuICAvLyBSZXEgUGFyYW1zXG4gIGNvbnN0IHsgcGFnZSA9IDEsIHNlYXJjaFF1ZXJ5ID0gJycgfSA9IHJlcS5xdWVyeTtcblxuICAvLyBGaWx0ZXJcbiAgaWYgKHNlYXJjaFF1ZXJ5KSB7XG4gICAgY29uc3QgcXVlcnlMb3dlciA9IHNlYXJjaFF1ZXJ5LnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKTtcbiAgICBzb3J0ZWRQb3N0cyA9IHNvcnRlZFBvc3RzLmZpbHRlcihcbiAgICAgIChwb3N0KSA9PlxuICAgICAgICBwb3N0LnRpdGxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocXVlcnlMb3dlcikgfHxcbiAgICAgICAgKHBvc3QuZGVzY3JpcHRpb24gJiYgcG9zdC5kZXNjcmlwdGlvbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5TG93ZXIpKSB8fFxuICAgICAgICAocG9zdC50YWcgJiYgcG9zdC50YWcudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxdWVyeUxvd2VyKSlcbiAgICApO1xuICB9XG5cbiAgLy8gUGFnaW5hdGlvblxuICBjb25zdCBwYWdpbmF0ZWRQb3N0cyA9IHNvcnRlZFBvc3RzLnNsaWNlKCgrcGFnZSAtIDEpICogUE9TVFNfUEVSX1BBR0UsICtwYWdlICogUE9TVFNfUEVSX1BBR0UpO1xuXG4gIHJlcy5zdGF0dXMoMjAwKS5qc29uKHtcbiAgICBwb3N0czogcGFnaW5hdGVkUG9zdHMsXG4gICAgdG90YWxQb3N0czogc29ydGVkUG9zdHMubGVuZ3RoLFxuICAgIHRvdGFsUGFnZXM6IE1hdGguY2VpbChzb3J0ZWRQb3N0cy5sZW5ndGggLyBQT1NUU19QRVJfUEFHRSksXG4gIH0pO1xufVxuIl0sIm5hbWVzIjpbImZzIiwicGF0aCIsIm1hdHRlciIsIlBPU1RTX1BFUl9QQUdFIiwiaGFuZGxlciIsInJlcSIsInJlcyIsInBvc3RzRGlyZWN0b3J5Iiwiam9pbiIsInByb2Nlc3MiLCJjd2QiLCJmaWxlTmFtZXMiLCJyZWFkZGlyU3luYyIsInBvc3RzIiwibWFwIiwiZmlsZU5hbWUiLCJmaWxlUGF0aCIsImZpbGVDb250ZW50cyIsInJlYWRGaWxlU3luYyIsImRhdGEiLCJzbHVnIiwicmVwbGFjZSIsInVybCIsInNvcnRlZFBvc3RzIiwic29ydCIsImEiLCJiIiwiRGF0ZSIsImRhdGUiLCJnZXRUaW1lIiwicGFnZSIsInNlYXJjaFF1ZXJ5IiwicXVlcnkiLCJxdWVyeUxvd2VyIiwidG9TdHJpbmciLCJ0b0xvd2VyQ2FzZSIsImZpbHRlciIsInBvc3QiLCJ0aXRsZSIsImluY2x1ZGVzIiwiZGVzY3JpcHRpb24iLCJ0YWciLCJwYWdpbmF0ZWRQb3N0cyIsInNsaWNlIiwic3RhdHVzIiwianNvbiIsInRvdGFsUG9zdHMiLCJsZW5ndGgiLCJ0b3RhbFBhZ2VzIiwiTWF0aCIsImNlaWwiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/latest.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next"], () => (__webpack_exec__("(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Flatest&preferredRegion=&absolutePagePath=.%2Fpages%2Fapi%2Flatest.ts&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();